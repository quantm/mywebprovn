<?
function get_clipvn($id){
$ch = curl_init();
curl_setopt($ch, CURLOPT_URL, 'http://clip.vn/ajax/login');
curl_setopt($ch, CURLOPT_HEADER, true);
curl_setopt($ch, CURLOPT_HTTPHEADER, array('X-Requested-With: XMLHttpRequest'));
curl_setopt($ch, CURLOPT_COOKIEJAR, 'cookie.txt');
curl_setopt($ch, CURLOPT_POST, true);
curl_setopt($ch, CURLOPT_POSTFIELDS, array('username' => 'Tài khoản clipvn', 'password' => 'Mật khẩu', 'persistent' => 1));
curl_setopt($ch, CURLOPT_URL, 'http://clip.vn/movies/nfo/'.$id);
curl_setopt($ch, CURLOPT_COOKIEFILE, 'cookie.txt');
curl_setopt($ch, CURLOPT_POSTFIELDS, array('onsite' => 'clip'));
curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
$data = curl_exec($ch);
curl_close($ch);
return $data;
}

function get_link($url){
	$get = file_get_contents('compress.zlib://'.$url);
	if($get){} else{redirect('/');}
	preg_match("/Clip.App.clipId = '(.*)';/U",$get,$id);
	preg_match_all("#<enclosure url='(.*?)' duration='([0-9]+)' id='(.*?)' type='(.*?)' quality='([0-9]+)' (.*?) />#is", get_clipvn($id[1]),$data)
	echo $data[1][0];
}
?>